﻿namespace NewKino.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string href { get; set; } = "";
        public string html_code { get; set; } = "";
        public string search { get; set; } = "";

    }
}
